# Covid-19 Statistical Study
This report focuses on a complete analysis of the Covid-19 pandemic and its effect on the world.

Covid-19 Global data is taken from https://ourworldindata.org/covid-deaths

Below is the Tableau presentation of the statistical study:

<img width="959" alt="image" src="https://github.com/shashankranjan3436/Covid-19-Statistical-Study/assets/83603244/6ee03999-01ac-44f2-b317-3f4c94197780">
